# Layout del chip de SonoVigía (SKY130)

Esta carpeta convierte el Verilog de SonoVigía en el **layout de un chip**: el dibujo de las capas de silicio y metal que se manda a fabricar. Usamos el proceso abierto **SkyWater SKY130** (130 nm) y el flujo libre **LibreLane**, el sucesor de OpenLane.

El resultado es un archivo **GDS** (`sonovigia_core.gds`), una imagen del layout y un resumen con área, número de celdas, potencia y timing. No hace falta instalar nada: un flujo de **GitHub Actions** de este repositorio genera todo (ver [Cómo generar el layout](#cómo-generar-el-layout)).

> **Estado:** el Verilog, la configuración y el flujo están listos. Las cifras e imágenes del layout real aparecen en `asic/resultados/` después de la primera corrida. Las imágenes de esta página son diagramas explicativos, no el layout.

## ¿Qué es un layout?

Un chip se fabrica capa por capa sobre una oblea de silicio. Abajo están los transistores (difusión y polisilicio). Encima, varias capas de metal los conectan entre sí y les llevan la energía. El layout es la **vista desde arriba** de todas esas capas: cada color de la imagen es una capa.

![Capas de SKY130](img/4_capas_sky130.png)

En un diseño digital no se dibujan transistores a mano. Se usan **celdas estándar**: compuertas (AND, OR, XOR…) y flip-flops ya dibujados por SkyWater (biblioteca `sky130_fd_sc_hd`), todos de la misma altura para acomodarlos en filas. El flujo decide qué celdas usar, dónde ponerlas y cómo cablearlas.

## Qué va en el chip

![Qué va dentro del chip](img/1_que_va_en_el_chip.png)

El chip contiene el **núcleo digital** de SonoVigía: el mismo Verilog que corre en la DE10-Lite, desde el filtro CIC hasta los displays. Hay tres diferencias, porque un chip SKY130 no tiene lo que trae el MAX 10:

| En la FPGA | En el chip | Por qué |
|---|---|---|
| ADC interno de 12 bits (IP `adc_core`) | ADC **externo** de 12 bits que entrega `adc_data[11:0]` y `adc_drdy` | SKY130 no incluye un ADC listo para usar |
| `adc_qsys` + `adc_if` (PLL de 10 MHz y cruce de reloj) | `adc_rx`: sincroniza `adc_drdy` con 3 flip-flops y copia el dato | Un solo reloj de 50 MHz; ya no hay PLL |
| `lvl_log`: registro de 24 h (691 kbit en M9K) | Se quita; el UART sigue mandando la línea de cada segundo | 86,400 × 8 bits hechos con flip-flops ocuparían varios mm² |

Todo lo demás es idéntico: `cic_dec`, `dc_block`, `a_weight_iir`, `ms_avg`, `db_lut`, `tod_clock`, `alarm_fsm`, `peak_hold`, `led_bar`, `disp_ctrl`, `buzzer_ctrl`, el UART y los sincronizadores. Los archivos de `src/` son copias de `rtl/` más dos nuevos: `sonovigia_core.v` (el top del chip) y `adc_rx.v`.

## Planta simulada (antes de correr el flujo)

![Planta simulada del chip](img/5_planta_simulada.png)

> **Esto no es el layout real.** Es un esquema hecho a partir del Verilog para explicar el chip antes de tener el GDS. En el layout real, OpenROAD decide dónde va cada celda y los bloques se mezclan entre sí.

La planta (floorplan, el plano de cómo se reparte el espacio del chip) se generó con `scripts/planta_simulada.py`:

1. **Cuenta los flip-flops reales.** Lee cada módulo de `src/` y suma los bits de registro que cambian con el reloj (los que se asignan con `<=` dentro de `always @(posedge clk)`). Usa los parámetros de cada instancia: por ejemplo, `io_sync` de los switches tiene 10 bits y el de KEY1 tiene 1.
2. **Estima el tamaño.** Cada bit de flip-flop cuenta como 50 unidades: un flip-flop de SKY130 mide unos 25 µm² y la lógica que lo rodea ocupa más o menos lo mismo. A eso se suman los bloques sin registros que pesan mucho: los 2 multiplicadores de 18×18, las tablas de umbrales de `db_lut`, los `bin2bcd`, los `hex7seg` y los comparadores de `led_bar`. Solo se muestran porcentajes, porque las cifras absolutas serían inventadas.
3. **Acomoda los bloques en columnas** en el orden en que pasa la señal: entradas → filtros → energía → dB → decisión y salidas. Los 87 pines van en el lado que fija `pin_order.cfg`.

Lo que enseña la imagen:

- **`ms_avg` es el bloque más grande (≈ 33 %).** Para el promedio Slow de 1 s guarda los últimos 8 bloques de 48 bits: 384 flip-flops solo para esa memoria, más su multiplicador para elevar al cuadrado.
- **`a_weight_iir` sigue (≈ 19 %)** por su multiplicador de 18×18 y los registros que guardan el estado de sus filtros (unos 300 bits).
- **Las dos copias de `db_lut` (≈ 9 % cada una)** pesan por su tabla de 144 umbrales de 48 bits.
- **Todo el control** (FSM de la alarma, reloj, pantallas, UART) ocupa menos de una cuarta parte del chip.
- El diseño tiene unos **1,866 bits de flip-flop** en total.

Para volver a generarla después de cambiar el Verilog:

```bash
python asic/scripts/planta_simulada.py asic/src asic/img/5_planta_simulada.png
```

## Pines

![Mapa de pines](img/2_mapa_de_pines.png)

El chip tiene **87 pines**. Sus nombres son los de la DE10-Lite, para que sea fácil compararlos. El lado de cada grupo se fija en `pin_order.cfg`.

| Lado | Pines | Dirección | Función |
|---|---|---|---|
| Oeste | `clk` | entrada | Reloj de 50 MHz |
| Oeste | `KEY[0]`, `KEY[1]` | entrada | Reset (activo en bajo); ajuste de hora y silencio |
| Oeste | `adc_drdy`, `adc_data[11:0]` | entrada | Muestras del ADC externo (1 MS/s) |
| Sur | `SW[9:0]` | entrada | Las mismas funciones que en la tarjeta |
| Sur | `LEDR[9:0]` | salida | Barra de nivel |
| Sur | `buzz`, `uart_txd`, `uart_rxd` | salida, salida, entrada | Buzzer y puerto serie de 115200 baudios |
| Norte | `HEX0`–`HEX2` (8 bits c/u) | salida | Displays, activos en bajo |
| Este | `HEX3`–`HEX5` (8 bits c/u) | salida | Displays, activos en bajo |

`uart_rxd` debe conectarse a 1 lógico si no se usa: en la FPGA lo hacía un pull-up, pero el núcleo no lo tiene. Los pines de energía (`VPWR`, `VGND`) los agrega el flujo.

## El flujo: del Verilog al GDS

![Flujo RTL a GDS](img/3_flujo_rtl_a_gds.png)

| Paso | Qué hace | Programa |
|---|---|---|
| Síntesis | Traduce el Verilog a compuertas de la biblioteca SKY130 | Yosys |
| Plano | Decide el tamaño del chip (núcleo al 40 % de ocupación), las filas de celdas y los pines | OpenROAD |
| Alimentación | Dibuja la rejilla de VPWR y VGND que lleva energía a todas las filas | OpenROAD |
| Colocación | Pone cada celda en su lugar, cerca de las que se conectan con ella | OpenROAD |
| Árbol de reloj | Reparte `clk` con buffers para que llegue a todos los flip-flops casi al mismo tiempo | OpenROAD |
| Ruteo | Traza los cables de metal entre las celdas | OpenROAD |
| Verificación | **DRC** revisa las reglas de fabricación; **LVS** revisa que el dibujo sea el mismo circuito que el Verilog; **STA** revisa el timing a 50 MHz | Magic, KLayout, Netgen, OpenSTA |
| GDS | Escribe el archivo final y una imagen | Magic, KLayout |

La configuración completa está en `config.json`:

```json
{
  "DESIGN_NAME": "sonovigia_core",
  "VERILOG_FILES": "dir::src/*.v",
  "CLOCK_PORT": "clk",
  "CLOCK_PERIOD": 20,
  "FP_CORE_UTIL": 40,
  "IO_PIN_ORDER_CFG": "dir::pin_order.cfg",
  "KLAYOUT_RENDER_RESOLUTION": 2000
}
```

`CLOCK_PERIOD` = 20 ns equivale a 50 MHz, el mismo reloj de la DE10-Lite. Por eso `tick_gen` y el UART no cambian.

## Cómo generar el layout

### Opción A: en GitHub, sin instalar nada (recomendada)

1. Sube al repositorio la carpeta `asic/` y el archivo `.github/workflows/asic.yml`.
2. En GitHub abre la pestaña **Actions**, elige **Layout ASIC (LibreLane, SKY130)** y pulsa **Run workflow**.
3. Espera a que termine (aproximadamente entre media hora y una hora). La primera vez descarga LibreLane y el PDK de SKY130.
4. Al final de la corrida, en **Artifacts**, descarga **layout-sonovigia**. Trae:
   - `resultados/RESUMEN.md`: área, celdas, potencia, timing, DRC y LVS;
   - `resultados/layout.png` y dos acercamientos (`zoom_25.png`, `zoom_08.png`);
   - `resultados/sonovigia_core.gds`: el archivo para fabricar;
   - `final/`: todas las salidas de LibreLane (DEF, LEF, netlist, SDF, reportes).
5. Copia la carpeta `resultados/` a `asic/resultados/` del repositorio para que las imágenes aparezcan en esta página.

El resumen también se muestra en la página de la corrida, sin descargar nada.

### Opción B: en tu computadora

Requiere Docker (en Windows, Docker Desktop con WSL2) y Python 3.10 o más reciente.

```bash
python -m pip install librelane
python -m librelane --dockerized --smoke-test          # prueba la instalación
python -m librelane --dockerized asic/config.json      # genera el layout
python asic/scripts/resumen.py asic/runs/<carpeta> asic/resultados
```

La primera corrida descarga la imagen de Docker y el PDK SKY130 (varios GB). Cada corrida queda en `asic/runs/RUN_<fecha>/`.

### Ver el layout de forma interactiva

```bash
python -m librelane --dockerized --last-run --flow openinklayout asic/config.json
```

Esto abre el GDS en KLayout: puedes acercarte hasta ver cada transistor y prender o apagar capas. También puedes abrir `sonovigia_core.gds` directamente en [KLayout](https://www.klayout.de/), que es gratuito.

## Resultados

Esta tabla se llena con `resultados/RESUMEN.md` después de la primera corrida.

| Métrica | Valor | Qué significa |
|---|---|---|
| Área del dado | _[ ] mm²_ | Tamaño total del chip |
| Celdas | _[ ]_ | Número de compuertas y flip-flops |
| Utilización | _[ ] %_ | Qué tanto del núcleo ocupan las celdas |
| Potencia total | _[ ] mW_ | Consumo estimado a 50 MHz |
| Holgura de setup | _[ ] ns_ | Positiva = el chip funciona a 50 MHz |
| Holgura de hold | _[ ] ns_ | Positiva = no hay datos que lleguen demasiado pronto |
| Errores DRC / LVS | _[ ] / [ ]_ | Deben ser 0 para poder fabricar |

![Layout completo](resultados/layout.png)

*Layout completo de `sonovigia_core`, generado por el paso KLayout.Render de LibreLane.*

![Acercamiento](resultados/zoom_08.png)

*Acercamiento al centro: se ven las filas de celdas estándar y los cables de metal.*

### Cómo leer la imagen

- Las **franjas anchas y regulares** son la rejilla de alimentación (VPWR y VGND).
- Las **filas horizontales** del fondo son las celdas estándar; cada fila mide lo mismo de alto.
- Las **líneas finas** de colores son los cables de señal, una dirección por capa de metal.
- Los **pines** están en el borde, en los lados que fija `pin_order.cfg`.

## Si algo falla

| Mensaje o síntoma | Causa probable | Qué hacer |
|---|---|---|
| Falla en `Verilator.Lint` o `Checker.LintErrors` | Un error de Verilog que Quartus aceptaba | Abre el log del paso en el artefacto y corrige la línea indicada |
| Falla en `Odb.CustomIOPlacement` | Un pin no coincide con `pin_order.cfg` | Revisa que todos los puertos de `sonovigia_core` aparezcan en el archivo |
| Holgura de setup negativa | Una ruta no alcanza los 20 ns | Sube `CLOCK_PERIOD`, pero cambia también `CLK_HZ` en `tick_gen` y el baud del UART |
| Errores de DRC o de congestión en el ruteo | Las celdas están muy apretadas | Baja `FP_CORE_UTIL` a 30 |
| `the input device is not a TTY` | Docker pide una terminal | El flujo ya usa `script` para dársela; en tu PC corre el comando desde una terminal normal |

## Archivos

```
asic/
  config.json          configuración de LibreLane
  pin_order.cfg        lado de cada pin
  src/                 Verilog del chip
    sonovigia_core.v   top del chip (basado en rtl/sonovigia_top.v)
    adc_rx.v           entrada del ADC externo (reemplaza adc_qsys + adc_if)
    ...                19 módulos copiados de rtl/
  tb/sonovigia_core_tb.v  prueba del núcleo con un ADC simulado (no entra al chip)
  scripts/resumen.py   junta métricas, imágenes y GDS después de una corrida
  scripts/planta_simulada.py  dibuja la planta simulada a partir de src/
  img/                 diagramas de esta página (5_planta_simulada.png es la planta)
  resultados/          (después de correr) RESUMEN.md, layout.png, GDS
.github/workflows/asic.yml   corre el flujo en GitHub Actions
```

Si cambias un módulo en `rtl/`, cópialo también a `asic/src/` antes de generar el layout.

## Límites

- **No está fabricado.** El GDS pasa las verificaciones del flujo, pero falta mandarlo a una corrida compartida (por ejemplo Tiny Tapeout o un shuttle de SKY130) y medirlo.
- **Faltan el ADC y el micrófono.** El chip espera un ADC externo de 12 bits a 1 MS/s. En la FPGA el ADC estaba dentro del MAX 10.
- **Sin registro de 24 h.** Para guardarlo se necesita memoria SRAM (macros de OpenRAM) o una memoria externa.
- **Simulación pendiente.** `tb/sonovigia_core_tb.v` prueba el núcleo completo con un ADC simulado (tono de 1 kHz, nivel esperado ≈ 107 dB), pero todavía no se ha corrido en Active-HDL:

  ```
  alog -dbg asic/src/*.v asic/tb/sonovigia_core_tb.v
  asim +access +r sonovigia_core_tb
  run -all
  ```

## Fuentes

- [Documentación de LibreLane](https://librelane.readthedocs.io/)
- [LibreLane: tutorial para principiantes](https://librelane.readthedocs.io/en/stable/getting_started/newcomers/index.html)
- [LibreLane: instalación con Docker en Ubuntu](https://librelane.readthedocs.io/en/latest/installation/docker_installation/installation_ubuntu.html)
- [LibreLane: pasos del flujo Classic](https://librelane.readthedocs.io/en/latest/reference/flows.html)
- [LibreLane: formato de `pin_order.cfg`](https://librelane.readthedocs.io/en/latest/reference/pin_placement_cfg.html)
- [LibreLane: PDKs](https://librelane.readthedocs.io/en/latest/usage/about_pdks.html)
- [Repositorio de LibreLane](https://github.com/librelane/librelane)
