# Resultados

Esta carpeta se llena después de correr el flujo (ver ../README.md, "Cómo generar el layout").
Las imágenes actuales son marcadores de lugar.
