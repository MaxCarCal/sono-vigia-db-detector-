`timescale 1ns/1ps
//==============================================================================
// sonovigia_core.v - Nucleo de SonoVigia para un chip ASIC (SKY130)
//------------------------------------------------------------------------------
// Es el mismo sistema que rtl/sonovigia_top.v (FPGA), con tres cambios que un
// chip necesita:
//
//   1) ADC: el MAX 10 trae un ADC interno; SKY130 no. Las muestras entran por
//      pines desde un ADC externo de 12 bits (adc_drdy + adc_data) y adc_rx
//      reemplaza a adc_qsys + adc_if.
//   2) Un solo reloj (clk, 50 MHz). Ya no hay PLL ni ADC_CLK_10.
//   3) Sin registro de 24 h (lvl_log): 691 kbit de memoria ocuparian decenas
//      de mm2 en flip-flops. La linea en vivo por UART se conserva; el
//      comando 'D' responde solo "END".
//
// Los nombres de los pines siguen los de la DE10-Lite (KEY, SW, LEDR, HEX)
// para que sea facil compararlos. Las salidas HEX son activas en bajo.
//
//   KEY[0]   reset (activo en bajo)        KEY[1]  ajuste / silencio
//   SW[9:0]  mismas funciones que en la FPGA
//   uart_rxd debe ir a '1' si no se usa (no hay pull-up dentro del nucleo)
//==============================================================================
module sonovigia_core #(
    parameter integer CAL_DB  = -18,   // calibracion (ver db_lut)
    parameter integer HOLD_S  = 3      // sosten de la alarma, 1..60 s
)(
    input  wire        clk,            // 50 MHz
    input  wire [1:0]  KEY,
    input  wire [9:0]  SW,
    // ADC externo, 12 bits, 1 MS/s
    input  wire        adc_drdy,
    input  wire [11:0] adc_data,
    // indicadores
    output wire [9:0]  LEDR,
    output wire [7:0]  HEX0,
    output wire [7:0]  HEX1,
    output wire [7:0]  HEX2,
    output wire [7:0]  HEX3,
    output wire [7:0]  HEX4,
    output wire [7:0]  HEX5,
    output wire        buzz,
    // UART 115200 8N1
    input  wire        uart_rxd,
    output wire        uart_txd
);

    localparam [5:0] HOLD6 = HOLD_S;

    //--------------------------------------------------------------------------
    // Reset e interfaz de usuario
    //--------------------------------------------------------------------------
    wire rst_n, rst;
    rst_sync u_rst (.clk(clk), .arst_n(KEY[0]), .rst_n(rst_n), .rst(rst));

    wire [9:0] sw;
    io_sync #(.WIDTH(10), .INIT(10'd0)) u_sw_sync (
        .clk(clk), .rst_n(rst_n), .async_in(SW),
        .sync_out(sw), .rise(), .fall()
    );

    wire key1_press;
    io_sync #(.WIDTH(1), .INIT(1'b1)) u_key_sync (
        .clk(clk), .rst_n(rst_n), .async_in(KEY[1]),
        .sync_out(), .rise(), .fall(key1_press)
    );

    wire [1:0]        mode_sw   = sw[1:0];
    wire              resp_slow = sw[2];
    wire              buzz_en   = sw[3];
    wire [1:0]        disp_sel  = sw[5:4];
    wire              set_min   = sw[6];
    wire signed [3:0] trim      = {sw[9], sw[9:7]};

    wire in_clock_mode = (disp_sel == 2'b10);
    wire inc_hour      = key1_press &&  in_clock_mode && !set_min;
    wire inc_min       = key1_press &&  in_clock_mode &&  set_min;
    wire key_action    = key1_press && !in_clock_mode;

    //--------------------------------------------------------------------------
    // Bases de tiempo
    //--------------------------------------------------------------------------
    wire tick_1hz, tick_4hz;
    tick_gen #(.CLK_HZ(50_000_000), .TICK_HZ(1)) u_tick1 (.clk(clk), .rst_n(rst_n), .tick(tick_1hz));
    tick_gen #(.CLK_HZ(50_000_000), .TICK_HZ(4)) u_tick4 (.clk(clk), .rst_n(rst_n), .tick(tick_4hz));

    reg blink;
    always @(posedge clk or negedge rst_n)
        if (!rst_n)        blink <= 1'b1;
        else if (tick_4hz) blink <= ~blink;

    //--------------------------------------------------------------------------
    // Entrada del ADC externo
    //--------------------------------------------------------------------------
    wire        s_valid, clip;
    wire [11:0] s_data;
    adc_rx u_adc_rx (
        .clk(clk), .rst_n(rst_n), .adc_drdy(adc_drdy), .adc_data(adc_data),
        .s_valid(s_valid), .s_data(s_data), .clip(clip)
    );

    //--------------------------------------------------------------------------
    // Procesamiento de senal (identico a la FPGA)
    //--------------------------------------------------------------------------
    wire               cic_v, dcb_v, aw_v;
    wire signed [15:0] cic_d, dcb_d;
    wire signed [17:0] aw_d;

    cic_dec      u_cic (.clk(clk), .rst_n(rst_n), .in_valid(s_valid), .in_data(s_data),
                        .out_valid(cic_v), .out_data(cic_d));
    dc_block     u_dcb (.clk(clk), .rst_n(rst_n), .in_valid(cic_v), .in_data(cic_d),
                        .out_valid(dcb_v), .out_data(dcb_d));
    a_weight_iir u_aw  (.clk(clk), .rst_n(rst_n), .in_valid(dcb_v), .in_data(dcb_d),
                        .out_valid(aw_v), .out_data(aw_d));

    wire        blk_valid, sec_flag;
    wire [47:0] fast_sum, slow_sum;
    ms_avg u_ms (.clk(clk), .rst_n(rst_n), .in_valid(aw_v), .in_data(aw_d),
                 .blk_valid(blk_valid), .sec_flag(sec_flag),
                 .fast_sum(fast_sum), .slow_sum(slow_sum));

    wire       sel_done;
    wire [7:0] raw_sel, level_sel;
    db_lut #(.CAL_DB(CAL_DB)) u_db_sel (
        .clk(clk), .rst_n(rst_n), .start(blk_valid),
        .x(resp_slow ? slow_sum : fast_sum), .trim(trim),
        .done(sel_done), .raw(raw_sel), .level(level_sel)
    );

    wire       s1_done;
    wire [7:0] raw_1s, level_1s;
    db_lut #(.CAL_DB(CAL_DB)) u_db_1s (
        .clk(clk), .rst_n(rst_n), .start(blk_valid & sec_flag),
        .x(slow_sum), .trim(trim),
        .done(s1_done), .raw(raw_1s), .level(level_1s)
    );

    //--------------------------------------------------------------------------
    // Reloj, limite y alarma
    //--------------------------------------------------------------------------
    wire [4:0] hour;
    wire [5:0] minute, second;
    wire [7:0] limit_db;
    wire [1:0] lim_mode;
    wire       is_night, event_expired;

    tod_clock u_tod (
        .clk(clk), .rst_n(rst_n), .tick_1hz(tick_1hz),
        .inc_hour(inc_hour), .inc_min(inc_min), .mode_sw(mode_sw),
        .hour(hour), .minute(minute), .second(second), .is_night(is_night),
        .limit_db(limit_db), .lim_mode(lim_mode), .event_expired(event_expired)
    );

    wire [1:0] alarm_state;
    wire       alert, pre, alert_start;
    alarm_fsm u_alarm (
        .clk(clk), .rst_n(rst_n), .tick(sel_done),
        .level(level_sel), .limit(limit_db), .hold_s(HOLD6),
        .state(alarm_state), .alert(alert), .pre(pre), .alert_start(alert_start)
    );

    //--------------------------------------------------------------------------
    // Indicadores
    //--------------------------------------------------------------------------
    reg [7:0] disp_level;
    always @(posedge clk or negedge rst_n)
        if (!rst_n)       disp_level <= 8'd0;
        else if (s1_done) disp_level <= level_sel;

    reg clip_seen, overload;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            clip_seen <= 1'b0;
            overload  <= 1'b0;
        end else if (s1_done) begin
            overload  <= clip_seen | clip;
            clip_seen <= 1'b0;
        end else if (clip) begin
            clip_seen <= 1'b1;
        end
    end

    wire [7:0] lmax;
    peak_hold u_peak (.clk(clk), .rst_n(rst_n), .in_valid(sel_done),
                      .level(level_sel), .clear(key_action), .max_level(lmax));

    led_bar #(.MIN_DB(45), .STEP_DB(6)) u_bar (.level(level_sel), .leds(LEDR));

    disp_ctrl u_disp (
        .clk(clk), .rst_n(rst_n), .sel(disp_sel),
        .level(disp_level), .lmax(lmax), .raw(raw_sel),
        .hour(hour), .minute(minute),
        .lim_mode(lim_mode), .alarm_state(alarm_state),
        .overload(overload), .blink(blink),
        .hex0(HEX0), .hex1(HEX1), .hex2(HEX2), .hex3(HEX3), .hex4(HEX4), .hex5(HEX5)
    );

    buzzer_ctrl u_buzz (.clk(clk), .rst_n(rst_n), .alert(alert), .enable(buzz_en),
                        .silence(key_action), .buzz(buzz));

    //--------------------------------------------------------------------------
    // UART: linea en vivo cada segundo (sin registro de 24 h)
    //--------------------------------------------------------------------------
    wire [16:0] log_count = 17'd0;
    wire [16:0] rd_idx;
    wire [7:0]  rd_data   = 8'd0;

    reg [7:0] state_char;
    always @* begin
        case (alarm_state)
            2'd1:    state_char = "P";
            2'd2:    state_char = "A";
            2'd3:    state_char = "C";
            default: state_char = "M";
        endcase
    end

    wire       rx_valid, tx_start, tx_busy;
    wire [7:0] rx_data, tx_data;

    uart_rx u_rx (.clk(clk), .rst_n(rst_n), .rx_in(uart_rxd),
                  .valid(rx_valid), .data(rx_data));

    log_uart u_fmt (
        .clk(clk), .rst_n(rst_n),
        .live_valid(s1_done), .live_level(level_1s), .state_char(state_char),
        .hh(hour), .mm(minute), .ss(second),
        .rx_valid(rx_valid), .rx_data(rx_data),
        .log_count(log_count), .rd_idx(rd_idx), .rd_data(rd_data),
        .tx_start(tx_start), .tx_data(tx_data), .tx_busy(tx_busy)
    );

    uart_tx u_tx (.clk(clk), .rst_n(rst_n), .start(tx_start), .data(tx_data),
                  .tx(uart_txd), .busy(tx_busy));

endmodule
