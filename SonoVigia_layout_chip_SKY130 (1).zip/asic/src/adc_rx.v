`timescale 1ns/1ps
//==============================================================================
// adc_rx.v - Entrada de muestras de un ADC EXTERNO (version ASIC de adc_if)
//------------------------------------------------------------------------------
// En la FPGA el ADC esta dentro del MAX 10. En un chip SKY130 no hay ADC, asi
// que las muestras llegan por pines desde un ADC externo de 12 bits:
//
//   adc_drdy  : "dato listo". Sube cuando hay una muestra nueva (1 MS/s).
//   adc_data  : la muestra, estable mientras adc_drdy = 1 (>= 100 ns).
//
// adc_drdy viene de otro reloj (el del ADC), asi que se sincroniza con 2
// flip-flops (d1, d2) antes de usarlo; d3 guarda el valor anterior para
// detectar el flanco de subida. El bus de datos NO se sincroniza bit a bit:
// se copia solo cuando el flanco ya paso por el sincronizador, momento en que
// el dato lleva varios ciclos estable (esquema de "senal de calificacion").
//
// Igual que adc_if, marca recorte (clip) si la muestra esta cerca de 0 o 4095.
//==============================================================================
module adc_rx #(
    parameter [11:0] CLIP_HI = 12'd4080,
    parameter [11:0] CLIP_LO = 12'd15
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        adc_drdy,
    input  wire [11:0] adc_data,
    output reg         s_valid,     // pulso de 1 ciclo por muestra
    output reg  [11:0] s_data,      // muestra de 12 bits, binario natural
    output reg         clip         // pulso: la muestra esta saturada
);

    reg d1, d2, d3;
    wire rise = d2 & ~d3;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            d1      <= 1'b0;
            d2      <= 1'b0;
            d3      <= 1'b0;
            s_valid <= 1'b0;
            s_data  <= 12'd2048;
            clip    <= 1'b0;
        end else begin
            d1      <= adc_drdy;     // primer FF: puede quedar metaestable
            d2      <= d1;           // segundo FF: valor estable
            d3      <= d2;           // valor anterior
            s_valid <= rise;
            clip    <= 1'b0;
            if (rise) begin
                s_data <= adc_data;
                clip   <= (adc_data >= CLIP_HI) || (adc_data <= CLIP_LO);
            end
        end
    end

endmodule
