#!/usr/bin/env python3
"""
resumen.py - Junta los resultados de una corrida de LibreLane en una carpeta
facil de revisar y de subir a GitHub.

Uso:   python asic/scripts/resumen.py asic/runs/<etiqueta> asic/resultados

Hace tres cosas:
  1) Lee final/metrics.json y escribe resultados/RESUMEN.md con las cifras
     principales (area, celdas, potencia, timing, DRC, LVS).
  2) Copia la imagen del layout que genera el paso KLayout.Render y crea dos
     acercamientos (zoom) con Pillow.
  3) Copia el GDS final (el archivo que se manda a fabricar).
Solo usa la biblioteca estandar y Pillow.
"""
import glob
import json
import os
import shutil
import sys

try:
    from PIL import Image
except ImportError:  # el resumen de texto funciona sin Pillow
    Image = None

# (clave en metrics.json, nombre en espanol, unidad, factor)
PRINCIPALES = [
    ("design__die__area",              "Area del dado",                 "mm2", 1e-6),
    ("design__core__area",             "Area del nucleo",               "mm2", 1e-6),
    ("design__instance__area",         "Area de celdas",                "mm2", 1e-6),
    ("design__instance__utilization",  "Utilizacion del nucleo",        "%",   100),
    ("design__instance__count",        "Instancias (celdas)",           "",    1),
    ("design__instance__count__stdcell", "Celdas estandar",             "",    1),
    ("power__total",                   "Potencia total (tipica)",       "mW",  1e3),
    ("power__internal__total",         "Potencia interna",              "mW",  1e3),
    ("power__switching__total",        "Potencia de conmutacion",       "mW",  1e3),
    ("power__leakage__total",          "Potencia de fuga",              "uW",  1e6),
    ("timing__setup__ws",              "Holgura de setup (peor)",       "ns",  1),
    ("timing__hold__ws",               "Holgura de hold (peor)",        "ns",  1),
    ("route__wirelength",              "Longitud de cable",             "um",  1),
    ("magic__drc_error__count",        "Errores DRC (Magic)",           "",    1),
    ("klayout__drc_error__count",      "Errores DRC (KLayout)",         "",    1),
    ("design__lvs_error__count",       "Errores LVS",                   "",    1),
    ("antenna__violating__nets__count", "Redes con violacion de antena", "",   1),
]


def fmt(v, factor):
    try:
        x = float(v) * factor
    except (TypeError, ValueError):
        return str(v)
    if abs(x) >= 1000 or x == int(x):
        return f"{x:,.0f}"
    return f"{x:,.4g}"


def main():
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(1)
    run, out = sys.argv[1], sys.argv[2]
    os.makedirs(out, exist_ok=True)
    lines = ["# Resultados del layout de SonoVigia (SKY130)", ""]

    # ---------------------------------------------------------------- metricas
    mfile = os.path.join(run, "final", "metrics.json")
    if not os.path.isfile(mfile):
        cand = sorted(glob.glob(os.path.join(run, "**", "metrics.json"), recursive=True))
        mfile = cand[-1] if cand else None
    if mfile:
        m = json.load(open(mfile))
        lines += ["| Metrica | Valor | Unidad |", "|---|---|---|"]
        for key, name, unit, factor in PRINCIPALES:
            if key in m:
                lines.append(f"| {name} | {fmt(m[key], factor)} | {unit} |")
        lines += ["", f"Fuente: `{os.path.relpath(mfile, run)}`.", ""]
        lines += ["<details><summary>Todas las metricas</summary>", "",
                  "| Clave | Valor |", "|---|---|"]
        for k in sorted(m):
            lines.append(f"| `{k}` | {m[k]} |")
        lines += ["", "</details>", ""]
        shutil.copy(mfile, os.path.join(out, "metrics.json"))
    else:
        lines += ["No se encontro metrics.json: la corrida no termino.", ""]

    # ---------------------------------------------------------------- imagen
    pngs = [p for p in glob.glob(os.path.join(run, "**", "*.png"), recursive=True)]
    pngs.sort(key=os.path.getsize, reverse=True)
    if pngs:
        src = pngs[0]
        shutil.copy(src, os.path.join(out, "layout.png"))
        lines += ["## Imagenes", "", "![Layout completo](layout.png)", ""]
        if Image is not None:
            img = Image.open(src).convert("RGB")
            w, h = img.size
            for name, frac in (("zoom_25.png", 0.25), ("zoom_08.png", 0.08)):
                cw, ch = int(w * frac), int(h * frac)
                box = ((w - cw) // 2, (h - ch) // 2, (w + cw) // 2, (h + ch) // 2)
                img.crop(box).resize((1200, int(1200 * ch / cw)), Image.LANCZOS).save(os.path.join(out, name))
                lines += [f"![Acercamiento al centro ({int(frac * 100)} % del ancho)]({name})", ""]
        lines += [f"Imagen original: `{os.path.relpath(src, run)}`.", ""]
    else:
        lines += ["No se encontro la imagen del paso KLayout.Render.", ""]

    # ---------------------------------------------------------------- GDS
    gds = glob.glob(os.path.join(run, "final", "gds", "*.gds"))
    if gds:
        shutil.copy(gds[0], os.path.join(out, os.path.basename(gds[0])))
        mb = os.path.getsize(gds[0]) / 1e6
        lines += ["## Archivo para fabricar", "",
                  f"`{os.path.basename(gds[0])}` ({mb:.1f} MB). Se abre con KLayout.", ""]

    open(os.path.join(out, "RESUMEN.md"), "w").write("\n".join(lines))
    print("\n".join(lines[:30]))


if __name__ == "__main__":
    main()
