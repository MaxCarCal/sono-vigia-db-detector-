#!/usr/bin/env python3
"""
planta_simulada.py - Dibuja una planta (floorplan) SIMULADA del chip de SonoVigia
a partir de la lista real de modulos de asic/src/.

Uso:   python asic/scripts/planta_simulada.py asic/src asic/img/5_planta_simulada.png

NO es el layout real. El layout real (GDS) lo genera LibreLane y la colocacion
la decide OpenROAD. Este dibujo sirve para explicar el chip antes de correr el
flujo:

  1) Lee cada modulo de asic/src y cuenta sus bits de flip-flop (registros que
     se asignan con <= dentro de un always @(posedge ...)), con los parametros
     de cada instancia (por ejemplo io_sync de 10 bits, tick_gen de 1 Hz y 4 Hz).
  2) Estima el tamano de cada bloque con un modelo simple:
        area ~ bits_de_FF * 50  +  extras
     50 = un flip-flop de SKY130 (sky130_fd_sc_hd__dfrtp_1, ~25 um2) mas la
     logica que lo rodea (~otro tanto). Extras: los 2 multiplicadores 18x18,
     la tabla de umbrales de db_lut, bin2bcd, hex7seg y los comparadores de
     led_bar. Solo se usan los PORCENTAJES, no las cifras absolutas.
  3) Acomoda los bloques en columnas siguiendo el camino de la senal
     (oeste -> este) y pone los 87 pines en el lado que fija pin_order.cfg.

Requiere matplotlib.
"""
import math
import os
import re
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Rectangle

# ----------------------------------------------------------------------------- conteo
def _strip(t):
    t = re.sub(r"/\*.*?\*/", "", t, flags=re.S)
    return re.sub(r"//[^\n]*", "", t)


def ff_bits(path, over=None):
    """Bits de flip-flop de un modulo, con parametros sobreescritos por instancia."""
    t = _strip(open(path, encoding="utf-8", errors="ignore").read())
    params = {}
    for pm in re.finditer(r"(?:parameter|localparam)\s+(?:integer\s+|signed\s+)*(?:\[[^\]]*\]\s*)?(\w+)\s*=\s*([^;\n]+)", t):
        v = re.split(r",\s*(?:parameter|localparam|\w+\s*=)", pm.group(2).strip())[0].strip().rstrip(",").strip()
        while v.count(")") > v.count("("):
            v = v[:v.rfind(")")].strip()
        params[pm.group(1)] = v
    params.update({k: str(v) for k, v in (over or {}).items()})

    def raw_eval(e, num):
        e = re.sub(r"\d+'[sS]?[dDbBhH]([0-9a-fA-F_]+)", r"\1", e.strip())
        e = re.sub(r"(?<=\d)_(?=\d)", "", e)
        for k, v in sorted(num.items(), key=lambda kv: -len(kv[0])):
            e = re.sub(r"\b%s\b" % k, str(v), e)
        m = re.match(r"^(.*?)\?(.*):(.*)$", e)
        if m:
            e = "((%s) if (%s) else (%s))" % (m.group(2), m.group(1), m.group(3))
        e = re.sub(r"(?<![/])/(?![/])", "//", e)
        return int(eval(e, {"__builtins__": {}, "clog2": lambda x: max(1, math.ceil(math.log2(x)))}))

    num = {}
    for _ in range(8):
        for k, v in params.items():
            if k not in num:
                try:
                    num[k] = raw_eval(v, num)
                except Exception:
                    pass

    def ev(e):
        try:
            return raw_eval(e, num)
        except Exception:
            return None

    def wid(rng):
        if not rng:
            return 1
        a, b = rng.strip("[]").split(":")
        a, b = ev(a), ev(b)
        return abs(a - b) + 1 if None not in (a, b) else 16

    widths = {}
    for line in t.splitlines():
        pm = re.search(r"output\s+reg\s+(?:signed\s+)?(\[[^\]]+\])?\s*(.*)$", line)
        if pm:
            for tok in pm.group(2).split(","):
                tok = tok.strip().rstrip(")").strip()
                if re.fullmatch(r"\w+", tok):
                    widths[tok] = wid(pm.group(1))
    for dm in re.finditer(r"^\s*reg\s+(?:signed\s+)?(\[[^\]]+\])?\s*([^;]+);", t, flags=re.M):
        w = wid(dm.group(1))
        for nm in dm.group(2).split(","):
            nm = nm.strip()
            am = re.match(r"(\w+)\s*\[([^\]:]+):([^\]]+)\]", nm)
            if am:
                a, b = ev(am.group(2)), ev(am.group(3))
                widths[am.group(1)] = w * ((abs(a - b) + 1) if None not in (a, b) else 1)
            elif re.match(r"\w+", nm):
                widths[re.match(r"(\w+)", nm).group(1)] = w
    seq = set()
    for am in re.finditer(r"always\s*@\s*\(\s*posedge[^)]*\)(.*?)(?=\balways\b|\bendmodule\b|\bassign\b|\bgenerate\b|\bfunction\b)", t, flags=re.S):
        for lm in re.finditer(r"(\w+)\s*(?:\[[^\]]*\])*\s*<=", am.group(1)):
            seq.add(lm.group(1))
    return sum(widths.get(s, 0) for s in seq)


# ----------------------------------------------------------------------------- modelo
# (instancia, modulo, parametros, extra_area, texto_extra, funcion, grupo)
EXTRA_MULT = 8000   # multiplicador 18x18 (~300 sumadores completos + productos parciales)
EXTRA_ROM = 4000    # tabla de 144 umbrales de 48 bits hecha con compuertas
EXTRA_BCD = 350     # un bin2bcd de 8 bits (combinacional)
EXTRA_7SEG = 120    # un hex7seg
EXTRA_BAR = 600     # 10 comparadores de 8 bits

INST = [
    ("adc_rx",       "adc_rx",       None,            0,                  "",                  "recibe el ADC externo",     "in"),
    ("rst_sync",     "rst_sync",     None,            0,                  "",                  "reset de KEY0",             "in"),
    ("io_sync SW",   "io_sync",      {"WIDTH": 10},   0,                  "",                  "sincroniza SW[9:0]",        "in"),
    ("io_sync KEY1", "io_sync",      {"WIDTH": 1},    0,                  "",                  "sincroniza KEY1",           "in"),
    ("tick_gen 1 Hz", "tick_gen",    {"TICK_HZ": 1},  0,                  "",                  "pulso de 1 s",              "in"),
    ("tick_gen 4 Hz", "tick_gen",    {"TICK_HZ": 4},  0,                  "",                  "pulso de 0.25 s",           "in"),
    ("cic_dec",      "cic_dec",      None,            0,                  "",                  "÷40, 1 MS/s → 25 kS/s",     "flt"),
    ("dc_block",     "dc_block",     None,            0,                  "",                  "quita los 2.5 V",           "flt"),
    ("a_weight_iir", "a_weight_iir", None,            EXTRA_MULT,         "mult 18×18",        "curva A (oído)",            "flt"),
    ("ms_avg",       "ms_avg",       None,            EXTRA_MULT,         "mult 18×18",        "energía Fast / Slow",       "nrg"),
    ("db_lut Fast",  "db_lut",       None,            EXTRA_ROM + 400,    "tabla 144×48",      "energía → dB (125 ms)",     "nrg"),
    ("db_lut 1 s",   "db_lut",       None,            EXTRA_ROM + 400,    "tabla 144×48",      "energía → dB (1 s)",        "nrg"),
    ("tod_clock",    "tod_clock",    None,            0,                  "",                  "hora y límite NOM-081",     "dec"),
    ("alarm_fsm",    "alarm_fsm",    None,            0,                  "",                  "FSM Moore de la alarma",    "dec"),
    ("peak_hold",    "peak_hold",    None,            0,                  "",                  "máximo Lmax",               "dec"),
    ("unión (top)",  "sonovigia_core", None,          0,                  "",                  "parpadeo, sobrecarga",      "dec"),
    ("disp_ctrl",    "disp_ctrl",    None,            3 * EXTRA_BCD + 6 * EXTRA_7SEG, "3 bin2bcd + 6 hex7seg", "6 displays", "out"),
    ("led_bar",      "led_bar",      None,            EXTRA_BAR,          "10 comparadores",   "barra LEDR",                "out"),
    ("buzzer_ctrl",  "buzzer_ctrl",  None,            0,                  "",                  "tono 2 kHz",                "out"),
    ("log_uart",     "log_uart",     None,            4 * EXTRA_BCD,      "4 bin2bcd",         "arma la línea CSV",         "out"),
    ("uart_tx",      "uart_tx",      None,            0,                  "",                  "envía a 115200",            "out"),
    ("uart_rx",      "uart_rx",      None,            0,                  "",                  "recibe comandos",           "out"),
]
FF_W = 50

GROUPS = {
    "in":  ("Entradas y tiempos", "#1f5fa8", "#dce8f7"),
    "flt": ("Filtros",            "#0b6e4f", "#d8efe5"),
    "nrg": ("Energía y dB",       "#b45309", "#fbe6cf"),
    "dec": ("Decisión",           "#9b2c5a", "#f6dfe9"),
    "out": ("Salidas",            "#5b4fa8", "#e6e2f6"),
}
INK, MUTED, EDGE = "#1f2933", "#616e7c", "#9aa5b1"


def build(src):
    rows = []
    for name, mod, over, extra, xtxt, func, grp in INST:
        ff = ff_bits(os.path.join(src, mod + ".v"), over)
        rows.append(dict(name=name, mod=mod, ff=ff, extra=extra, xtxt=xtxt, func=func, grp=grp,
                         area=ff * FF_W + extra))
    total = sum(r["area"] for r in rows)
    for r in rows:
        r["pct"] = 100.0 * r["area"] / total
    return rows


# ----------------------------------------------------------------------------- dibujo
def fill(weights, total, minimum):
    """Reparte 'total' en proporcion a 'weights', pero sin bajar de 'minimum'."""
    fixed = set()
    while True:
        free = total - minimum * len(fixed)
        wsum = sum(w for i, w in enumerate(weights) if i not in fixed)
        out = [minimum if i in fixed else free * w / wsum for i, w in enumerate(weights)]
        low = {i for i, v in enumerate(out) if v < minimum and i not in fixed}
        if not low:
            return out
        fixed |= low


def draw(rows, out):
    plt.rcParams["font.family"] = "DejaVu Sans"
    by = {r["name"]: r for r in rows}
    fig = plt.figure(figsize=(19, 11.2), dpi=150)
    fig.patch.set_facecolor("white")

    # ---------- titulo
    fig.text(0.018, 0.965, "Planta del chip SonoVigía (SIMULADA)", fontsize=20, weight="bold", color=INK, va="top")
    fig.text(0.018, 0.928, "Hecha con los módulos reales de asic/src: 22 bloques (bin2bcd y hex7seg van dentro de "
             "disp_ctrl y log_uart).\nLos tamaños son estimados; el layout real (GDS) lo genera LibreLane y puede "
             "acomodar todo distinto.", fontsize=11.5, color=MUTED, va="top", linespacing=1.45)

    # ---------- chip
    ax = fig.add_axes([0.02, 0.02, 0.56, 0.84])
    ax.set_xlim(-14, 114); ax.set_ylim(-9, 109); ax.set_aspect("equal"); ax.axis("off")

    # dado, anillo de pines y nucleo
    ax.add_patch(Rectangle((0, 0), 100, 100, fc="#f4f5f7", ec="#3e4c59", lw=2.2))
    C0, C1 = 8, 92
    ax.add_patch(Rectangle((C0, C0), C1 - C0, C1 - C0, fc="#fbfbfc", ec="#7b8794", lw=1.0, ls="--"))
    # filas de celdas estandar
    y = C0 + 1.2
    while y < C1 - 0.5:
        ax.plot([C0 + 0.6, C1 - 0.6], [y, y], color="#e4e7eb", lw=0.6, zorder=1)
        y += 1.6
    # rejilla de alimentacion
    x = C0 + 4
    k = 0
    while x < C1 - 1:
        ax.plot([x, x], [C0 + 0.3, C1 - 0.3], color="#c99a2e" if k % 2 == 0 else "#7a8fa6", lw=1.1, alpha=0.45, zorder=1)
        x += 7.5
        k += 1

    # ---------- pines (pin_order.cfg)
    sides = {
        "N": [("HEX0[7:0]", 8, "out"), ("HEX1[7:0]", 8, "out"), ("HEX2[7:0]", 8, "out")],
        "E": [("HEX3[7:0]", 8, "out"), ("HEX4[7:0]", 8, "out"), ("HEX5[7:0]", 8, "out")],
        "S": [("SW[9:0]", 10, "in"), ("LEDR[9:0]", 10, "out"), ("buzz", 1, "out"), ("uart_rxd", 1, "in"), ("uart_txd", 1, "out")],
        "W": [("clk", 1, "in"), ("KEY[1:0]", 2, "in"), ("adc_drdy", 1, "in"), ("adc_data[11:0]", 12, "in")],
    }
    npins = 0
    for side, groups in sides.items():
        n = sum(g[1] for g in groups)
        npins += n
        span0, span1 = 10, 90
        step = (span1 - span0) / n
        i = 0
        for label, cnt, grp in groups:
            col = GROUPS[grp][1]
            g0 = i
            for _ in range(cnt):
                p = span0 + step * (i + 0.5)
                if side == "N":
                    ax.add_patch(Rectangle((p - step * 0.32, 100 - 3.2), step * 0.64, 3.2, fc=col, ec="none"))
                elif side == "S":
                    ax.add_patch(Rectangle((p - step * 0.32, 0), step * 0.64, 3.2, fc=col, ec="none"))
                elif side == "W":
                    ax.add_patch(Rectangle((0, 100 - p - step * 0.32), 3.2, step * 0.64, fc=col, ec="none"))
                else:
                    ax.add_patch(Rectangle((100 - 3.2, 100 - p - step * 0.32), 3.2, step * 0.64, fc=col, ec="none"))
                i += 1
            a = span0 + step * g0
            b = span0 + step * i
            mid = (a + b) / 2
            fs = 8.6
            if side == "N":
                ax.plot([a + 0.3, b - 0.3], [101.4, 101.4], color=col, lw=1.4)
                ax.text(mid, 102.6, label, ha="center", va="bottom", fontsize=fs, color=col, weight="bold")
            elif side == "S":
                ax.plot([a + 0.3, b - 0.3], [-1.4, -1.4], color=col, lw=1.4)
                rot = 0 if cnt >= 8 else 90
                ax.text(mid, -2.6, label, ha="center", va="top", fontsize=fs, color=col, weight="bold", rotation=rot)
            elif side == "W":
                ax.plot([-1.4, -1.4], [100 - a - 0.3, 100 - b + 0.3], color=col, lw=1.4)
                ax.text(-2.6, 100 - mid, label, ha="right", va="center", fontsize=fs, color=col, weight="bold")
            else:
                ax.plot([101.4, 101.4], [100 - a - 0.3, 100 - b + 0.3], color=col, lw=1.4)
                ax.text(102.6, 100 - mid, label, ha="left", va="center", fontsize=fs, color=col, weight="bold", rotation=270)
    for side, (xx, yy, rot) in {"Norte": (50, 108.2, 0), "Sur": (50, -8.4, 0), "Oeste": (-12.8, 50, 90), "Este": (112.8, 50, 270)}.items():
        ax.text(xx, yy, side, ha="center", va="center", fontsize=10, color=MUTED, rotation=rot, style="italic")

    # ---------- bloques: columnas en el orden de la senal (oeste -> este)
    cols = [
        ["adc_rx", "rst_sync", "io_sync SW", "io_sync KEY1", "tick_gen 1 Hz", "tick_gen 4 Hz"],
        ["cic_dec", "dc_block", "a_weight_iir"],
        ["ms_avg"],
        ["db_lut Fast", "db_lut 1 s"],
        ["disp_ctrl", "tod_clock", "alarm_fsm", "peak_hold", "unión (top)", "led_bar", "buzzer_ctrl", "log_uart", "uart_tx", "uart_rx"],
    ]
    MIN_W, MIN_H, GAP = 13.0, 4.6, 1.0
    X0, X1, Y0, Y1 = C0 + 1.5, C1 - 1.5, C0 + 1.5, C1 - 1.5
    avail = (X1 - X0) - GAP * (len(cols) - 1)
    cw = fill([sum(by[n]["pct"] for n in c) for c in cols], avail, MIN_W)
    centers = []
    x = X0
    for c, w in zip(cols, cw):
        avail_h = (Y1 - Y0) - GAP * (len(c) - 1)
        hs = fill([by[n]["pct"] for n in c], avail_h, MIN_H)
        y = Y1
        col_centers = []
        for n, h in zip(c, hs):
            r = by[n]
            _, ec, fc = GROUPS[r["grp"]]
            ax.add_patch(Rectangle((x, y - h), w, h, fc=fc, ec=ec, lw=1.6, alpha=0.93, zorder=3))
            big = h >= 9 and w >= 14
            name_fs = 10.5 if big else 8.2
            if h >= 6.5:
                ax.text(x + w / 2, y - h / 2 + (1.6 if big else 1.0), r["name"], ha="center", va="center",
                        fontsize=name_fs, weight="bold", color=ec, zorder=4)
                ax.text(x + w / 2, y - h / 2 - (1.0 if big else 1.2), "%d FF · %.0f %%" % (r["ff"], r["pct"]),
                        ha="center", va="center", fontsize=7.8, color=INK, zorder=4)
                if big:
                    ax.text(x + w / 2, y - h / 2 - 3.4, r["func"], ha="center", va="center", fontsize=8, color=MUTED, zorder=4)
                    if r["xtxt"]:
                        ax.text(x + w / 2, y - h / 2 - 5.6, r["xtxt"], ha="center", va="center", fontsize=7.6,
                                color=ec, style="italic", zorder=4)
            else:
                ax.text(x + w / 2, y - h / 2, r["name"], ha="center", va="center",
                        fontsize=7.4, weight="bold", color=ec, zorder=4)
            col_centers.append((x, y - h / 2, w, y, h))
            y -= h + GAP
        centers.append(col_centers)
        x += w + GAP

    # flechas del camino de la senal
    def link(a, b):
        (xa, ya, wa, _, _), (xb, yb, wb, _, _) = a, b
        ax.add_patch(FancyArrowPatch((xa + wa - 0.6, ya), (xb + 0.6, yb), arrowstyle="-|>", mutation_scale=13,
                                     color="#3e4c59", lw=1.5, zorder=5, connectionstyle="arc3,rad=0.0"))
    link(centers[0][0], centers[1][0])   # adc_rx -> cic
    def down(a, b):
        xa, _, wa, ytop_a, ha = a
        _, _, _, ytop_b, _ = b
        xm = xa + wa * 0.88
        ax.add_patch(FancyArrowPatch((xm, ytop_a - ha + 1.6), (xm, ytop_b - 1.2), arrowstyle="-|>",
                                     mutation_scale=11, color="#3e4c59", lw=1.3, zorder=5))
    down(centers[1][0], centers[1][1])   # cic -> dc_block
    down(centers[1][1], centers[1][2])   # dc_block -> a_weight
    link(centers[1][2], centers[2][0])   # a_weight -> ms_avg
    link(centers[2][0], centers[3][0])   # ms_avg -> db_lut
    link(centers[2][0], centers[3][1])
    link(centers[3][0], centers[4][2])   # db_lut -> alarm_fsm

    ax.text(50, 4.9, "núcleo: celdas estándar sky130_fd_sc_hd en filas  ·  rejilla VPWR / VGND", ha="center",
            fontsize=8, color=MUTED, zorder=6)

    # ---------- panel derecho: tabla
    tx = fig.add_axes([0.605, 0.015, 0.385, 0.865]); tx.axis("off")
    tx.set_xlim(0, 100); tx.set_ylim(0, 100)
    tx.text(0, 99.5, "Bloques del chip (asic/src)", fontsize=13.5, weight="bold", color=INK, va="top")
    hdr_y = 95.2
    cx = [0, 30, 61, 72, 85]
    for c, h in zip(cx, ["Bloque", "Qué hace", "FF*", "Extra", "Tamaño**"]):
        tx.text(c, hdr_y, h, fontsize=9.4, weight="bold", color=MUTED, va="center")
    tx.plot([0, 100], [hdr_y - 1.6, hdr_y - 1.6], color=EDGE, lw=0.8)
    gorder = ["in", "flt", "nrg", "dec", "out"]
    order = [n for g in gorder for c in cols for n in c if by[n]["grp"] == g]
    ystep = 2.9
    yy = hdr_y - 3.6
    last_grp = None
    for n in order:
        r = by[n]
        name, ec, fc = GROUPS[r["grp"]]
        if r["grp"] != last_grp:
            tx.text(0, yy, name.upper(), fontsize=8, weight="bold", color=ec, va="center")
            yy -= ystep * 0.8
            last_grp = r["grp"]
        tx.add_patch(Rectangle((0, yy - 1.0), 1.4, 2.0, fc=ec, ec="none"))
        tx.text(2.4, yy, r["name"], fontsize=9, color=INK, va="center", family="DejaVu Sans Mono")
        tx.text(cx[1], yy, r["func"], fontsize=8.6, color=INK, va="center")
        tx.text(cx[2] + 7, yy, "%d" % r["ff"], fontsize=8.8, color=INK, va="center", ha="right")
        tx.text(cx[3], yy, r["xtxt"].replace("3 bin2bcd + 6 hex7seg", "BCD+7seg").replace("10 comparadores", "10 comp.")
                .replace("tabla 144×48", "tabla"), fontsize=8, color=MUTED, va="center")
        bw = r["pct"] / 40.0 * 7.5
        tx.add_patch(Rectangle((cx[4], yy - 0.9), max(bw, 0.25), 1.8, fc=fc, ec=ec, lw=0.8))
        tx.text(cx[4] + max(bw, 0.25) + 0.8, yy, "%.1f %%" % r["pct"], fontsize=8, color=INK, va="center")
        yy -= ystep
    tot_ff = sum(r["ff"] for r in rows)
    tx.plot([0, 100], [yy + 1.3, yy + 1.3], color=EDGE, lw=0.8)
    tx.text(2.4, yy - 0.6, "Total", fontsize=9.2, weight="bold", color=INK, va="center")
    tx.text(cx[2] + 7, yy - 0.6, "%d" % tot_ff, fontsize=9.2, weight="bold", color=INK, va="center", ha="right")
    tx.text(cx[4], yy - 0.6, "100 %", fontsize=9, weight="bold", color=INK, va="center")
    notes = [
        "* FF = bits de flip-flop contados en el Verilog de cada bloque (registros con <= en un always @(posedge clk)).",
        "** Tamaño estimado: FF × 50 + extras (2 multiplicadores 18×18, 2 tablas de db_lut, bin2bcd, hex7seg, comparadores).",
        "ms_avg es el bloque más grande: guarda 8 bloques de 48 bits (384 FF) para el promedio Slow de 1 s.",
        "Los bloques muy pequeños se dibujaron con un tamaño mínimo para poder leer su nombre.",
        "Pines: %d, en el lado que fija pin_order.cfg; su orden exacto dentro de cada lado lo decide el flujo." % npins,
    ]
    ny = yy - 3.6
    for s in notes:
        tx.text(0, ny, s, fontsize=7.7, color=MUTED, va="top")
        ny -= 2.45

    # sello
    fig.text(0.372, 0.962, "SIMULADO · NO ES EL GDS", fontsize=11.5, weight="bold", color="#b42318", ha="left", va="top",
             bbox=dict(boxstyle="round,pad=0.35", fc="#fdecea", ec="#b42318", lw=1.2))
    fig.savefig(out, dpi=150, facecolor="white")
    return tot_ff, npins


if __name__ == "__main__":
    src = sys.argv[1] if len(sys.argv) > 1 else "asic/src"
    out = sys.argv[2] if len(sys.argv) > 2 else "asic/img/5_planta_simulada.png"
    rows = build(src)
    for r in rows:
        print("%-14s %5d FF  %5.1f %%" % (r["name"], r["ff"], r["pct"]))
    tot, npins = draw(rows, out)
    print("total FF = %d, pines = %d -> %s" % (tot, npins, out))
