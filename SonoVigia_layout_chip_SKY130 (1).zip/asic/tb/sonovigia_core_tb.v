`timescale 1ns/1ps
//==============================================================================
// sonovigia_core_tb.v - Prueba del nucleo del chip con un ADC externo simulado
//------------------------------------------------------------------------------
// Simula un ADC de 12 bits a 1 MS/s que entrega un tono de 1 kHz con amplitud
// 1500 (de 2048 posibles). Con CAL_DB = -18, escala completa se lee como 110 dB,
// asi que este tono debe medir cerca de 110 + 20*log10(1500/2048) = 107 dB.
//
// Revisa, despues de 1.3 s simulados:
//   - nivel del display entre 100 y 115 dB
//   - los 10 LEDR encendidos (el ultimo umbral es 99 dB)
//   - alarma en PRE-ALERTA (P): el limite de dia es 55 dB y aun no pasan 3 s
//   - el UART ya envio la linea del primer segundo
//
// Active-HDL:  alog -dbg asic/src/*.v asic/tb/sonovigia_core_tb.v
//              asim +access +r sonovigia_core_tb
//              run -all
// Son ~65 millones de ciclos: puede tardar varios minutos.
//==============================================================================
module sonovigia_core_tb;

    reg clk = 1'b0;
    always #10 clk = ~clk;                       // 50 MHz

    reg  [1:0]  KEY      = 2'b10;                // KEY0 = 0: en reset al inicio
    reg  [9:0]  SW       = 10'b00_0000_0001;     // limite dia (55), Fast, nivel
    reg         adc_drdy = 1'b0;
    reg  [11:0] adc_data = 12'd2048;

    wire [9:0] LEDR;
    wire [7:0] HEX0, HEX1, HEX2, HEX3, HEX4, HEX5;
    wire       buzz, uart_txd;

    sonovigia_core dut (
        .clk(clk), .KEY(KEY), .SW(SW),
        .adc_drdy(adc_drdy), .adc_data(adc_data),
        .LEDR(LEDR),
        .HEX0(HEX0), .HEX1(HEX1), .HEX2(HEX2), .HEX3(HEX3), .HEX4(HEX4), .HEX5(HEX5),
        .buzz(buzz), .uart_rxd(1'b1), .uart_txd(uart_txd)
    );

    // ---------------- ADC externo: una muestra cada 1 us, drdy alto 200 ns
    real    amp = 1500.0;
    integer n   = 0;
    always begin
        #800;
        adc_data = 12'd2048 + $rtoi(amp * $sin(2.0 * 3.14159265358979 * 1000.0 * n * 1.0e-6));
        adc_drdy = 1'b1;
        #200;
        adc_drdy = 1'b0;
        n = n + 1;
    end

    // ---------------- actividad del UART
    integer tx_edges = 0;
    always @(negedge uart_txd) tx_edges = tx_edges + 1;

    // ---------------- secuencia
    integer errors = 0;
    initial begin
        #200 KEY = 2'b11;                        // suelta el reset
        #1300000000;                             // 1.3 s

        $display("nivel en display = %0d dB, LEDR = %b, estado alarma = %0d, flancos UART = %0d",
                 dut.disp_level, LEDR, dut.alarm_state, tx_edges);

        if (dut.disp_level < 100 || dut.disp_level > 115) begin
            $display("ERROR: nivel fuera de 100..115 dB"); errors = errors + 1;
        end
        if (LEDR !== 10'b11_1111_1111) begin
            $display("ERROR: la barra deberia estar completa"); errors = errors + 1;
        end
        if (dut.alarm_state !== 2'd1) begin
            $display("ERROR: se esperaba PRE-ALERTA (1)"); errors = errors + 1;
        end
        if (tx_edges == 0) begin
            $display("ERROR: el UART no envio nada"); errors = errors + 1;
        end

        if (errors == 0) $display("PASS sonovigia_core_tb");
        else             $display("FAIL sonovigia_core_tb (%0d errores)", errors);
        $finish;
    end

endmodule
